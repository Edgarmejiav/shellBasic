# ! /bin/bash
# Programa para ejemplificar el empaquetamiento con el comando tar

echo "Empaquetar todos los scripts de la carpeta shellCourse"
tar -cvf shellCourse.tar *.sh

